package com.n2017748079.main.controller;


import com.n2017748079.main.domain.Basic;
import com.n2017748079.main.domain.Profile;
import com.n2017748079.main.repository.BasicRepository;
import com.n2017748079.main.repository.ProfileRepository;
import com.n2017748079.main.service.BasicService;
import com.n2017748079.main.service.ProfileService;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;

@Controller
public class BasicController {

    private BasicService basicService;
    private BasicRepository basicRepository;
    private ProfileService profileService;
    private ProfileRepository profileRepository;



    public BasicController(BasicService basicService, BasicRepository basicRepository, ProfileService profileService, ProfileRepository profileRepository) {
        this.basicService = basicService;
        this.basicRepository = basicRepository;
        this.profileService = profileService;
        this.profileRepository = profileRepository;

    }


    @GetMapping("/")
    public String list(@PageableDefault Pageable pageable, Model model) {
        model.addAttribute("basicList", basicService.findBasicList(pageable));
        model.addAttribute("profileList", profileService.findProfileList(pageable));
        return "index";
    }


    @GetMapping("/basic/{idx}")
    public String read(@PathVariable Long idx, Model model) {
        model.addAttribute("basic", basicService.findBasicByIdx(idx));
        return "basicItem";
    }


    @GetMapping("/profile/{idx}")
    public String read2(@PathVariable Long idx, Model model) {
        model.addAttribute("profile", profileService.findProfileByIdx(idx));
        return "profileItem";
    }


    @PostMapping("/basic/add")
    public String add(Basic basic, Model model) {
        basic.setCreatedDate(LocalDateTime.now());
        basic.setUpdatedDate(LocalDateTime.now());
        Basic saveBasic = basicRepository.save(basic);
        model.addAttribute("basic", basicService.findBasicByIdx(saveBasic.getIdx()));
        return "basicItem";
    }

    @PostMapping("/profile/add")
    public String add2(Profile profile, Model model) {
        profile.setCreateDat(LocalDateTime.now());
        profile.setUpdatedDate(LocalDateTime.now());
        Profile saveProfile = profileRepository.save(profile);
        model.addAttribute("profile", profileService.findProfileByIdx(saveProfile.getIdx()));
        return "profileItem";
    }


    @GetMapping("/basic/new")
    public String form(Basic basic) {
        return "basicNew";
    }

    @GetMapping("/profile/new")
    public String form(Profile profile) {
        return "profileNew";


    }

}
