package com.n2017748079.main.controller;

import com.n2017748079.main.repository.BasicRepository;
import com.n2017748079.main.repository.ProfileRepository;

public class BasicJsonController {
    private BasicRepository basicRepository;
    private ProfileRepository profileRepository;


    public BasicJsonController(BasicRepository basicRepository,ProfileRepository profileRepository){
        this.basicRepository = basicRepository;
        this.profileRepository = profileRepository;
    }

}
