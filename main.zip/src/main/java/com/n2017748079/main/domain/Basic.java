package com.n2017748079.main.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table
public class Basic implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long idx;

    @Column
    public String name;

    @Column
    public String label;

    @Column
    public String email;

    @Column
    public String phone;

    @Column
    private LocalDateTime createdDate;

    @Column
    private LocalDateTime updatedDate;


    @Builder
    public Basic(String name, String label, String email, String phone, LocalDateTime createdDate, LocalDateTime updatedDate) {
        this.name = name;
        this.label = label;
        this.email = email;
        this.phone = phone;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }
}
