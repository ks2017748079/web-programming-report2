package com.n2017748079.main.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table
public class Profile implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    private String network;

    @Column
    private String userName;

    @Column
    private String url;

    @Column
    private LocalDateTime createDat;

    @Column
    private LocalDateTime updatedDate;

    @Builder

    public Profile(String network, String userName, String url, LocalDateTime createDat, LocalDateTime updatedDate) {
        this.network = network;
        this.userName = userName;
        this.url = url;
        this.createDat = createDat;
        this.updatedDate = updatedDate;
    }
}